package com.iwork.miaosha.dao;

public interface UserDao {


}

