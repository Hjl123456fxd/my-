package com.iwork.miaosha.controller;

import com.iwork.miaosha.result.CodeMsg;
import com.iwork.miaosha.result.Result;
import com.iwork.miaosha.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/cute")
public class SampleController {

    @Autowired
    UserService userService;
    @RequestMapping("/thy")
    public String thymeleaf(Model model) {

        model.addAttribute("name", "xiaoming");
        return "Hello";
    }
    @RequestMapping("/")
    @ResponseBody
    public String home(){
        return "Hello World!";
    }

    @RequestMapping("/hello")
    @ResponseBody
    public Result<String> hello(){
        return Result.success("hello,小爱同学");
    }
    @RequestMapping("/heError")
    @ResponseBody
    public Result helloError(){
        return Result.error(CodeMsg.SERVER_ERROR);
    }



}

