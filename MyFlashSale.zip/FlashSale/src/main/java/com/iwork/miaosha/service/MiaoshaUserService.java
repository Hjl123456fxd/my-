package com.iwork.miaosha.service;


import org.springframework.stereotype.Service;

@Service
public class MiaoshaUserService {

}
