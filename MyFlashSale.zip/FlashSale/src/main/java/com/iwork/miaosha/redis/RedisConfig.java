package com.iwork.miaosha.redis;

public class RedisConfig {
}
